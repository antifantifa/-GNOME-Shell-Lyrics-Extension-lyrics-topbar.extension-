const { Gtk, Gio, GObject } = imports.gi;
const ExtensionUtils = imports.misc.extensionUtils;

function init() {}

function buildPrefsWidget() {
    const settings = ExtensionUtils.getSettings('org.gnome.shell.extensions.lyrics-indicator');
    
    const prefsWidget = new Gtk.Box({ 
        orientation: Gtk.Orientation.VERTICAL, 
        spacing: 20, 
        margin_top: 20, 
        margin_bottom: 20, 
        margin_start: 20, 
        margin_end: 20 
    });

    const createRow = (labelStr, child) => {
        let box = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL, spacing: 10 });
        let label = new Gtk.Label({ label: labelStr, xalign: 0, hexpand: true });
        box.append(label);
        box.append(child);
        return box;
    };

    let fontBtn = new Gtk.FontButton({ font: settings.get_string('font'), use_font: true });
    fontBtn.connect('font-set', (btn) => settings.set_string('font', btn.get_font()));
    prefsWidget.append(createRow('Top Bar Font', fontBtn));

    let lenSpin = Gtk.SpinButton.new_with_range(10, 100, 1);
    lenSpin.set_value(settings.get_int('max-line-length'));
    lenSpin.connect('value-changed', (s) => settings.set_int('max-line-length', s.get_value_as_int()));
    prefsWidget.append(createRow('Max Line Length', lenSpin));

    let rainbowSwitch = new Gtk.Switch({ active: settings.get_boolean('color-animation') });
    rainbowSwitch.connect('notify::active', (s) => settings.set_boolean('color-animation', s.get_active()));
    prefsWidget.append(createRow('Rainbow Animation', rainbowSwitch));

    let speedScale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.1, 5.0, 0.1);
    speedScale.set_draw_value(true);
    speedScale.set_value(settings.get_double('animation-speed'));
    speedScale.set_size_request(150, -1);
    speedScale.connect('value-changed', (s) => settings.set_double('animation-speed', s.get_value()));
    prefsWidget.append(createRow('Animation Speed (0.1x - 5x)', speedScale));

    let geniusEntry = new Gtk.Entry({ 
        text: settings.get_string('genius-api-token'),
        visibility: false, 
        placeholder_text: "Paste Token Here"
    });
    geniusEntry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "system-lock-screen-symbolic");
    geniusEntry.set_width_chars(30);
    geniusEntry.connect('changed', (e) => settings.set_string('genius-api-token', e.get_text()));
    prefsWidget.append(createRow('Genius API Token', geniusEntry));

    return prefsWidget;
}
