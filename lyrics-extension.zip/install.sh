#!/bin/bash
echo "Installing schemas..."
mkdir -p schemas
glib-compile-schemas schemas/
echo "Done. Please restart GNOME Shell (Alt+F2 -> r)"
